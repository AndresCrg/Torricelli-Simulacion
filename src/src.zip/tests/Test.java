package tests;

import controller.Controller;

public class Test {
    public static void main(String[] args) {
        new Controller();
    }
}
