package controller;

import models.ToricelliEngine;
import views.MainFrame;

public class Controller {
    private MainFrame mf;
    private ToricelliEngine te;

    public Controller() {
        initComponents();
    }

    private void initComponents( ){
        mf = new MainFrame();
        te = new ToricelliEngine(20,2, 10,0.2, 10, 3, 10, 0.1, 2, mf);
    }
}
